create
    definer = bookadmin@localhost procedure SP_MEMBER_DELETE(IN userid varchar(20), OUT rtn_code int)
BEGIN

    IF userid NOT IN(SELECT m_userid FROM tb_member) THEN
        SET rtn_code = 0;
    ELSE
        delete from tb_member
        where m_userid = userid;
        SET rtn_code = 1;
    end if;

END;

