create
    definer = bookadmin@localhost procedure SP_MEMBER_INSERT(IN V_USERID varchar(20), IN V_PWD varchar(20),
                                                             IN V_EMAIL varchar(50), IN V_HP varchar(20),
                                                             OUT RTN_CODE int)
BEGIN
    if v_userid in (select m_userid from TB_MEMBER) then
	    set rtn_code = 100;
    else
        insert into TB_MEMBER(m_userid, m_pwd, m_email, m_hp) values(v_userid, v_pwd, v_email, v_hp);
        set rtn_code = 200;
    end if;
END;

