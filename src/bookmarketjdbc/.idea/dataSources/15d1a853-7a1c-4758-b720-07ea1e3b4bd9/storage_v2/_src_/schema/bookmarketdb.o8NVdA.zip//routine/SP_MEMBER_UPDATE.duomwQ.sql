create
    definer = bookadmin@localhost procedure SP_MEMBER_UPDATE(IN num int, IN userid varchar(20), IN input varchar(20),
                                                             OUT rtn_code int)
BEGIN
    CASE
        WHEN num = 1 THEN
        UPDATE TB_MEMBER SET m_pwd = input where m_userid = userid;

        WHEN num = 2 THEN
        UPDATE TB_MEMBER SET m_email = input where m_userid = userid;

        WHEN num = 3 THEN
        UPDATE TB_MEMBER SET m_hp = input where m_userid = userid;
    END CASE;

    IF userid NOT IN(SELECT m_userid FROM tb_member) THEN
        SET rtn_code = 0;
    ELSE
        SET rtn_code = 1;
    end if;

END;

