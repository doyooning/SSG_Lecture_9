create
    definer = bookadmin@localhost procedure SP_MEMBER_SEARCH(IN userid varchar(20))
BEGIN
    select *
    from tb_member
    where m_userid = userid;

END;

