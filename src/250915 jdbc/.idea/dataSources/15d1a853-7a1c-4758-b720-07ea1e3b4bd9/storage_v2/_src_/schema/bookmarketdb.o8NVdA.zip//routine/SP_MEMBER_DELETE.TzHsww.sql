create
    definer = bookadmin@localhost procedure SP_MEMBER_DELETE(IN userid varchar(20))
BEGIN
    delete from tb_member
    where m_userid = userid;

END;

